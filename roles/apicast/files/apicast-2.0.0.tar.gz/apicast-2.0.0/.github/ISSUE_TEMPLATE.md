[provide a description of the issue]


##### Version

[provide output of the `nginx -V` or `openresty -V` command from openshift/local terminal]
[provide timestamp of the docker image from `docker inspect --format='{{.Created}}' quay.io/3scale/apicast:v2` ]

##### Steps To Reproduce

1. [step 1 (json configuration file, if applies)]
2. [step 2 (curl commands to reproduce, if applies)]
3. [step 3]

##### Current Result

##### Expected Result

##### Additional Information

* [Gist with minimal reproducible configuration, see guidelines for contributing for details]
* [Gist with nginx log output]
